# Instalação Rápida - ZID Proxy no pfSense

## 📦 Versão: 1.0.0

Este guia mostra como instalar o zid-proxy-pfsense-v1.0.0.tar.gz no pfSense.

## 🚀 Instalação Rápida

### Passo 1: Copiar arquivo para o pfSense

```bash
# Do seu computador
scp zid-proxy-pfsense-v1.0.0.tar.gz root@SEU-PFSENSE-IP:/tmp/
```

### Passo 2: Extrair e instalar

```bash
# Conectar ao pfSense
ssh root@SEU-PFSENSE-IP

# Extrair o pacote
cd /tmp
tar -xzf zid-proxy-pfsense-v1.0.0.tar.gz
cd zid-proxy-pfsense

# Executar instalador
cd pkg-zid-proxy
sh install.sh
```

O instalador irá:
1. ✓ Copiar todos os arquivos necessários
2. ✓ Criar o script RC automaticamente
3. ✓ Perguntar se deseja registrar no pfSense (responda "yes")
4. ✓ Mostrar instruções para completar a instalação

### Passo 3: Verificar instalação

```bash
# Testar o serviço
/usr/local/etc/rc.d/zid-proxy.sh start
/usr/local/etc/rc.d/zid-proxy.sh status

# Ver logs
tail -f /var/log/zid-proxy.log
```

### Passo 4: Acessar interface web

1. Recarregue a interface web do pfSense:
   ```bash
   /usr/local/sbin/pfSsh.php playback reloadwebgui
   ```

2. Acesse: **Services > ZID Proxy**

3. Configure:
   - ☑ Enable
   - Interface: LAN
   - Port: 3129 (ou conforme sua necessidade)
   - ☑ Enable Logging

4. Adicione regras na aba **Access Rules**

5. Configure NAT redirect em **Firewall > NAT > Port Forward**

---

## 🔧 Solução de Problemas

### Erro: "service not found"

Se o comando `service zid-proxy` não funcionar:

```bash
cd /tmp/zid-proxy-pfsense/pkg-zid-proxy
php activate-package.php
```

### Menu não aparece na GUI

```bash
cd /tmp/zid-proxy-pfsense/pkg-zid-proxy
php register-package.php
/usr/local/sbin/pfSsh.php playback reloadwebgui
```

### Diagnóstico completo

```bash
cd /tmp/zid-proxy-pfsense/pkg-zid-proxy
sh diagnose.sh
```

### Reinstalar do zero

```bash
cd /tmp/zid-proxy-pfsense/pkg-zid-proxy
sh uninstall.sh
sh install.sh
```

---

## 📋 Estrutura do Pacote

```
zid-proxy-pfsense/
├── build/zid-proxy              # Binário para FreeBSD
├── pkg-zid-proxy/
│   ├── install.sh               # Instalador principal ⭐
│   ├── activate-package.php     # Cria RC script
│   ├── register-package.php     # Registra no pfSense
│   ├── diagnose.sh              # Diagnóstico
│   ├── uninstall.sh             # Desinstalador
│   ├── README.md                # Documentação detalhada
│   └── files/                   # Arquivos do pacote
├── scripts/rc.d/zid-proxy       # Script RC standalone
├── configs/access_rules.txt     # Regras de exemplo
└── README.md                    # Documentação geral
```

---

## 📖 Documentação

- **Documentação completa**: `README.md`
- **Troubleshooting detalhado**: `pkg-zid-proxy/README.md`
- **Instruções para desenvolvedores**: `CLAUDE.md`

---

## ✅ Verificação Pós-Instalação

Execute este checklist:

- [ ] Binário instalado: `ls -lh /usr/local/sbin/zid-proxy`
- [ ] RC script existe: `ls -lh /usr/local/etc/rc.d/zid-proxy.sh`
- [ ] Serviço inicia: `/usr/local/etc/rc.d/zid-proxy.sh start`
- [ ] Processo rodando: `ps aux | grep zid-proxy`
- [ ] Menu aparece na GUI: Services > ZID Proxy
- [ ] Log funciona: `tail /var/log/zid-proxy.log`

---

## 🆘 Suporte

Se encontrar problemas:

1. Execute: `cd /tmp/zid-proxy-pfsense/pkg-zid-proxy && sh diagnose.sh`
2. Verifique os logs: `tail -100 /var/log/zid-proxy.log`
3. Leia: `pkg-zid-proxy/README.md`

---

**Versão do Binário**: 1.0.0
**Data de Build**: 2025-12-16
**Compatível com**: pfSense 2.7.0+ (FreeBSD 15.x)
